package ao.path2.mscomputeroutes

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class MsComputeRoutesApplication

fun main(args: Array<String>) {
	runApplication<MsComputeRoutesApplication>(*args)
}
