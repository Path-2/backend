package ao.path2.mscomputeroutes

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MsComputeRoutesApplicationTests {

	@Test
	fun contextLoads() {
	}

}
