package ao.path2.mscomputeroutes

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class MsComputeRoutesApplication {

	static void main(String[] args) {
		SpringApplication.run(MsComputeRoutesApplication, args)
	}

}
